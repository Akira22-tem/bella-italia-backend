-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-08-2024 a las 17:36:01
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bd_bella_italia`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle`
--

CREATE TABLE `detalle` (
  `id` bigint(20) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `id_pedido` bigint(20) DEFAULT NULL,
  `id_productos` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle`
--

INSERT INTO `detalle` (`id`, `cantidad`, `id_pedido`, `id_productos`) VALUES
(2, 10, 1, 5),
(3, 2, 1, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `id` bigint(20) NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `fecha_ingreso` datetime(6) DEFAULT NULL,
  `id_productos` bigint(20) NOT NULL,
  `id_provedores` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mesas`
--

CREATE TABLE `mesas` (
  `id` bigint(20) NOT NULL,
  `capacidad` int(11) NOT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `mesa` int(11) DEFAULT NULL,
  `tipo` varchar(255) DEFAULT NULL,
  `ubicacion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mesas`
--

INSERT INTO `mesas` (`id`, `capacidad`, `estado`, `mesa`, `tipo`, `ubicacion`) VALUES
(1, 4, 'disponible', 12, 'al aire libre', 'Terraza'),
(2, 1, 'Actualizado', 3, 'Actualizado', 'Actualizado'),
(4, 8, 'no disponible', 15, 'familiar', 'Patio');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id` bigint(20) NOT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `fecha_pedido` datetime(6) DEFAULT NULL,
  `total` double NOT NULL,
  `id_mesa` bigint(20) DEFAULT NULL,
  `id_usuario` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id`, `estado`, `fecha_pedido`, `total`, `id_mesa`, `id_usuario`) VALUES
(1, 'Actualizado', '0002-11-30 09:30:00.000000', 0, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` bigint(20) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `nombre` varchar(255) NOT NULL,
  `precio` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `cantidad`, `descripcion`, `nombre`, `precio`) VALUES
(1, 3, 'descripcion prueba 1', 'Producto prueba 1', 10),
(3, 2, 'descripcion Actualizado', 'Producto Actualizado', 10),
(4, 7, 'Calzone relleno de queso ricotta, mozzarella, jamón y champiñones', 'Calzone', 14.75),
(5, 10, 'Pizza clásica con salsa de tomate, mozzarella fresca y albahaca', 'Pizza Margherita', 12.5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provedores`
--

CREATE TABLE `provedores` (
  `id` bigint(20) NOT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `fecha_ingreso` datetime(6) DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `precio_compra` float DEFAULT NULL,
  `producto` varchar(255) DEFAULT NULL,
  `telefono` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `provedores`
--

INSERT INTO `provedores` (`id`, `direccion`, `estado`, `fecha_ingreso`, `nombre`, `precio_compra`, `producto`, `telefono`) VALUES
(2, 'Actualizado', 'Actualizado', '2024-04-19 19:00:00.000000', 'Actualizado', 50, 'Actualizado', '987654321'),
(3, 'Calle de las Huertas, 789', 'activo', '2024-05-31 19:00:00.000000', 'Frescos del Campo', 30, 'Tomates Frescos', '234567890'),
(4, 'Ruta de los Embutidos, 101', 'activo', '2024-06-09 19:00:00.000000', 'Embutidos del Valle', 80, 'Pepperoni', '345678901');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas`
--

CREATE TABLE `reservas` (
  `id` bigint(20) NOT NULL,
  `cantidad_personas` int(11) DEFAULT NULL,
  `fecha_expiracion` datetime(6) DEFAULT NULL,
  `fecha_reserva` datetime(6) DEFAULT NULL,
  `mesa_id` bigint(20) DEFAULT NULL,
  `usuario_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reservas`
--

INSERT INTO `reservas` (`id`, `cantidad_personas`, `fecha_expiracion`, `fecha_reserva`, `mesa_id`, `usuario_id`) VALUES
(1, 4, '2024-10-16 15:30:00.000000', '2024-10-11 13:30:00.000000', 4, 4),
(4, 10, '2024-08-16 15:30:00.000000', '2024-08-11 13:30:00.000000', 4, 2),
(5, 10, '2024-09-16 15:30:00.000000', '2024-09-11 13:30:00.000000', 1, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `fecha_actualizacion` datetime(6) DEFAULT NULL,
  `fecha_creacion` datetime(6) DEFAULT NULL,
  `rol` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `descripcion`, `estado`, `fecha_actualizacion`, `fecha_creacion`, `rol`) VALUES
(1, 'descripcion 1', 'Activo', '2024-07-07 19:00:00.000000', '2024-07-07 19:00:00.000000', 'Prueba 1'),
(2, 'descripcion 2', 'Inactivo', '2024-07-07 19:00:00.000000', '2024-07-07 19:00:00.000000', 'Prueba 2'),
(4, 'descripcion Actualizada', 'Actualizado', '2024-07-07 19:00:00.000000', '2024-07-07 19:00:00.000000', 'Rol Actualizado'),
(5, 'Responsable de preparar y cocinar pizzas de alta calidad siguiendo recetas específicas, asegurando el uso de ingredientes frescos y manteniendo altos estándares de higiene en la cocina.', 'Activo', '2024-07-07 19:00:00.000000', '2024-07-07 19:00:00.000000', 'Pizzero'),
(6, 'Encargado de procesar los pagos de los clientes, manejar el efectivo y las transacciones electrónicas, y proporcionar un servicio al cliente eficiente y amigable.', 'Activo', '2024-07-07 19:00:00.000000', '2024-07-07 19:00:00.000000', 'Cajero');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transacciones`
--

CREATE TABLE `transacciones` (
  `id` bigint(20) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `monto` double NOT NULL,
  `tipo` varchar(255) DEFAULT NULL,
  `fecha_creacion` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `transacciones`
--

INSERT INTO `transacciones` (`id`, `descripcion`, `monto`, `tipo`, `fecha_creacion`) VALUES
(2, 'Venta de pizzas margarita y pepperoni', 45.5, 'ingreso', '2024-07-19 08:45:00.000000'),
(3, 'Pago de servicios de electricidad', 125, 'gasto', '2024-07-20 04:00:00.000000'),
(4, 'Pago recibido', 100, 'ingreso', '2024-07-18 19:00:00.000000'),
(6, 'Actualizado', 30, 'Actualizado', '2024-07-21 05:00:00.000000');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` bigint(20) NOT NULL,
  `apellido` varchar(255) DEFAULT NULL,
  `cedula` varchar(255) DEFAULT NULL,
  `ciudad` varchar(255) DEFAULT NULL,
  `correo` varchar(255) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `telefono` varchar(255) DEFAULT NULL,
  `id_rol` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `apellido`, `cedula`, `ciudad`, `correo`, `direccion`, `nombre`, `password`, `telefono`, `id_rol`) VALUES
(1, 'Morales', '1750522532', 'Quito', 'admorales7@example.com', 'Av. Siempre Viva 123', 'Alexis', 'password1', '0980981027', NULL),
(2, 'Yanez', '1758124567', 'Cuenca', 'aryanez@example.com', 'Av. Cuenca 123', 'Carlos', 'password2', '0988336428', NULL),
(4, 'apellido actualizado', '0000000000', 'actualizado', 'actualizado@example.com', 'actualizado', 'Usuario actualizado', 'actualizado', '0000000000', NULL),
(5, 'Hernan', '0401430699', 'Chimborazo', 'lrhernan@example.com', 'Av. Guayacan 123', 'Roberto', 'password4', '0998263145', NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `detalle`
--
ALTER TABLE `detalle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKrpl3bdj3445t80gwjhc3y26b` (`id_pedido`),
  ADD KEY `FKcs3l6s9yh7mcfr3i0bnleqdvt` (`id_productos`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK54b38mitaguuhlrk69v8gh48c` (`id_productos`),
  ADD KEY `FKqot3wqhoh9rxcjw5qquqpmvul` (`id_provedores`);

--
-- Indices de la tabla `mesas`
--
ALTER TABLE `mesas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK6lnywvattil83fkuh1f9v1cak` (`id_mesa`),
  ADD KEY `FK4a0lfwlpmytywxpwjfa1a3ar2` (`id_usuario`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `provedores`
--
ALTER TABLE `provedores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKk33nidm20a0k0ssnyjfjmnnnp` (`mesa_id`),
  ADD KEY `FKcfh7qcr7oxomqk5hhbxdg2m7p` (`usuario_id`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `transacciones`
--
ALTER TABLE `transacciones`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK3kl77pehgupicftwfreqnjkll` (`id_rol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `detalle`
--
ALTER TABLE `detalle`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `inventario`
--
ALTER TABLE `inventario`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `mesas`
--
ALTER TABLE `mesas`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `provedores`
--
ALTER TABLE `provedores`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `transacciones`
--
ALTER TABLE `transacciones`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalle`
--
ALTER TABLE `detalle`
  ADD CONSTRAINT `FKcs3l6s9yh7mcfr3i0bnleqdvt` FOREIGN KEY (`id_productos`) REFERENCES `productos` (`id`),
  ADD CONSTRAINT `FKrpl3bdj3445t80gwjhc3y26b` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id`);

--
-- Filtros para la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD CONSTRAINT `FK54b38mitaguuhlrk69v8gh48c` FOREIGN KEY (`id_productos`) REFERENCES `productos` (`id`),
  ADD CONSTRAINT `FKqot3wqhoh9rxcjw5qquqpmvul` FOREIGN KEY (`id_provedores`) REFERENCES `provedores` (`id`);

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `FK4a0lfwlpmytywxpwjfa1a3ar2` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `FK6lnywvattil83fkuh1f9v1cak` FOREIGN KEY (`id_mesa`) REFERENCES `mesas` (`id`);

--
-- Filtros para la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD CONSTRAINT `FKcfh7qcr7oxomqk5hhbxdg2m7p` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `FKk33nidm20a0k0ssnyjfjmnnnp` FOREIGN KEY (`mesa_id`) REFERENCES `mesas` (`id`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `FK3kl77pehgupicftwfreqnjkll` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
